/* global React */
const { useState } = React;

const A_BRAND = '#A8226B';
const A_BRAND_DEEP = '#7A0F49';
const A_INK = '#1C1614';
const A_INK_SOFT = '#5B524D';
const A_CREAM = '#F6F0E8';
const A_CREAM_DEEP = '#EDE3D5';
const A_RULE = '#D9CCBA';

// Warm tonal placeholders — no fake imagery
const Placeholder = ({ h = 420, label, tone = 'warm', ratio }) => {
  const palettes = {
    warm: ['#E8DAC4', '#D8C4A8'],
    deep: ['#C9B294', '#B69874'],
    pale: ['#F0E6D6', '#E2D2BA'],
    plum: ['#E8D7DC', '#D6B9C2'],
  };
  const [a, b] = palettes[tone];
  return (
    <div style={{
      position: 'relative', height: h, aspectRatio: ratio,
      background: `linear-gradient(135deg, ${a} 0%, ${b} 100%)`,
      overflow: 'hidden',
    }}>
      <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0, opacity: 0.12, mixBlendMode: 'multiply' }} preserveAspectRatio="none">
        <defs>
          <pattern id={`p-${label}`} width="2" height="2" patternUnits="userSpaceOnUse">
            <rect width="2" height="2" fill="transparent" />
            <circle cx="1" cy="1" r="0.3" fill="#1C1614" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill={`url(#p-${label})`} />
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'flex-end', justifyContent: 'flex-start',
        padding: '20px 22px', color: '#1C1614',
        fontFamily: '"Manrope", sans-serif', fontSize: 10, letterSpacing: '0.18em',
        textTransform: 'uppercase', opacity: 0.55,
      }}>
        <span>{label}</span>
      </div>
    </div>
  );
};

const Tag = ({ children }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 8,
    fontFamily: '"Manrope", sans-serif', fontSize: 11, letterSpacing: '0.24em',
    textTransform: 'uppercase', color: A_BRAND, fontWeight: 500,
  }}>
    <span style={{ width: 18, height: 1, background: A_BRAND }} />
    {children}
  </span>
);

const ServiceRow = ({ num, title, blurb, mark }) => (
  <div style={{
    display: 'grid', gridTemplateColumns: '60px 1fr 1fr 60px',
    gap: 32, padding: '38px 0', borderTop: `1px solid ${A_RULE}`,
    alignItems: 'baseline',
  }}>
    <div style={{ fontFamily: '"Manrope", sans-serif', fontSize: 12, letterSpacing: '0.2em', color: A_INK_SOFT }}>{num}</div>
    <div style={{
      fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
      fontSize: 36, color: A_INK, lineHeight: 1.05, fontWeight: 500,
    }}>{title}</div>
    <div style={{
      fontFamily: '"Manrope", sans-serif', fontSize: 14, lineHeight: 1.65,
      color: A_INK_SOFT, maxWidth: 320,
    }}>{blurb}</div>
    <div style={{ textAlign: 'right' }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%', border: `1px solid ${A_BRAND}`,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        color: A_BRAND, fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
        fontSize: 14,
      }}>{mark}</div>
    </div>
  </div>
);

const VariationA = () => (
  <div style={{
    width: 1280, background: A_CREAM, color: A_INK,
    fontFamily: '"Manrope", sans-serif', fontSize: 14, lineHeight: 1.5,
  }}>
    {/* NAV */}
    <header style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '28px 64px', borderBottom: `1px solid ${A_RULE}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 28, height: 28, background: A_BRAND, position: 'relative',
        }}>
          <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0 }}>
            <path d="M 48 22 Q 56 26 54 38 Q 50 50 46 60 Q 44 72 50 82 L 38 82 Q 32 74 34 62 Q 38 50 42 38 Q 44 28 48 22 Z" fill="#fff"/>
          </svg>
        </div>
        <div style={{ lineHeight: 1 }}>
          <div style={{
            fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
            fontSize: 22, color: A_BRAND, fontWeight: 500,
          }}>máxxima</div>
          <div style={{ fontSize: 9, letterSpacing: '0.32em', color: A_INK_SOFT, marginTop: 2 }}>ORTOPEDIA</div>
        </div>
      </div>
      <nav style={{ display: 'flex', gap: 36, fontSize: 12, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
        <a style={{ color: A_INK }}>A clínica</a>
        <a style={{ color: A_INK }}>Tratamentos</a>
        <a style={{ color: A_INK }}>Jornada</a>
        <a style={{ color: A_INK }}>Contato</a>
      </nav>
      <a style={{
        fontFamily: '"Manrope", sans-serif', fontSize: 11, letterSpacing: '0.22em', textTransform: 'uppercase',
        color: A_BRAND, borderBottom: `1px solid ${A_BRAND}`, paddingBottom: 4,
      }}>Agendar consulta →</a>
    </header>

    {/* HERO */}
    <section style={{ padding: '88px 64px 96px', position: 'relative' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1.15fr 1fr', gap: 64, alignItems: 'center' }}>
        <div>
          <Tag>Ortopedia de pés e tornozelo</Tag>
          <h1 style={{
            fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
            fontSize: 92, lineHeight: 0.98, letterSpacing: '-0.015em',
            margin: '28px 0 0', color: A_INK,
          }}>
            Cada passo<br/>
            <em style={{ color: A_BRAND, fontWeight: 500 }}>merece</em> ser<br/>
            cuidado <em style={{ color: A_BRAND, fontWeight: 500 }}>com&nbsp;rigor.</em>
          </h1>
          <p style={{
            marginTop: 32, fontSize: 15, lineHeight: 1.7, color: A_INK_SOFT, maxWidth: 460,
          }}>
            Atendimento clínico dedicado exclusivamente ao pé e ao tornozelo —
            do diagnóstico baropodométrico à palmilha sob medida. Uma clínica para
            quem entende que dor crônica não é destino.
          </p>
          <div style={{ marginTop: 44, display: 'flex', gap: 14, alignItems: 'center' }}>
            <a style={{
              background: A_INK, color: A_CREAM, padding: '16px 28px',
              fontSize: 11, letterSpacing: '0.22em', textTransform: 'uppercase',
              display: 'inline-flex', alignItems: 'center', gap: 12,
            }}>Agendar pelo WhatsApp <span style={{ fontSize: 14 }}>→</span></a>
            <a style={{
              color: A_INK, padding: '16px 4px', fontSize: 11, letterSpacing: '0.22em',
              textTransform: 'uppercase', borderBottom: `1px solid ${A_INK}`,
            }}>(11) 0000-0000</a>
          </div>
          <div style={{ marginTop: 56, display: 'flex', gap: 40 }}>
            {[
              ['Especialidade única', 'Pé & tornozelo'],
              ['Avaliação', 'Baropodometria digital'],
              ['Bairro', 'Campo Belo, SP'],
            ].map(([k, v]) => (
              <div key={k}>
                <div style={{ fontSize: 9, letterSpacing: '0.24em', textTransform: 'uppercase', color: A_INK_SOFT }}>{k}</div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 18, marginTop: 6, color: A_INK }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ position: 'relative' }}>
          <Placeholder h={620} label="Retrato clínico — paciente · ambiente" tone="deep" />
          <div style={{
            position: 'absolute', bottom: -28, left: -28, width: 200,
            background: A_CREAM, padding: '20px 22px', border: `1px solid ${A_RULE}`,
          }}>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 28, color: A_BRAND, lineHeight: 1 }}>
              16<span style={{ fontSize: 14 }}>anos</span>
            </div>
            <div style={{ fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: A_INK_SOFT, marginTop: 8 }}>
              Dedicados ao<br/>pé e tornozelo
            </div>
          </div>
        </div>
      </div>
    </section>

    {/* RULE + manifesto */}
    <section style={{ padding: '80px 64px', borderTop: `1px solid ${A_RULE}`, background: A_CREAM_DEEP }}>
      <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 80 }}>
        <Tag>A clínica</Tag>
        <div>
          <p style={{
            fontFamily: '"Cormorant Garamond", serif', fontSize: 38, lineHeight: 1.25,
            fontWeight: 400, color: A_INK, margin: 0, letterSpacing: '-0.005em',
          }}>
            Acreditamos que o cuidado ortopédico do pé exige <em style={{ color: A_BRAND }}>tempo, escuta e instrumental preciso</em>. 
            Por isso construímos uma clínica de especialidade única — onde cada paciente é avaliado por quem dedicou a carreira inteira a esta articulação.
          </p>
          <div style={{ marginTop: 40, display: 'flex', gap: 60 }}>
            <div>
              <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 12, color: A_BRAND, letterSpacing: '0.02em' }}>Dra. Cibele Réssio · CRM-SP 72.981 · RQE 104.807</div>
              <div style={{ fontSize: 11, color: A_INK_SOFT, marginTop: 4 }}>Responsável técnica</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    {/* SERVICES */}
    <section style={{ padding: '120px 64px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 60 }}>
        <div>
          <Tag>Tratamentos</Tag>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontSize: 64, fontWeight: 400,
            margin: '20px 0 0', letterSpacing: '-0.015em', lineHeight: 1,
          }}>
            Seis cuidados,<br/>
            <em style={{ color: A_BRAND }}>uma especialidade.</em>
          </h2>
        </div>
        <div style={{ fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: A_INK_SOFT }}>
          06 — Procedimentos
        </div>
      </div>
      <div>
        <ServiceRow num="01" mark="•" title="Consulta ortopédica" blurb="Avaliação clínica completa do pé e tornozelo, com exame funcional, palpação e revisão de exames de imagem." />
        <ServiceRow num="02" mark="•" title="Palmilha posturais personalizadas" blurb="Confeccionadas sob medida a partir do mapeamento da sua pisada — corrigem apoio, distribuem carga, aliviam dor." />
        <ServiceRow num="03" mark="•" title="Avaliação baropodométrica" blurb="Mapeamento digital da pressão plantar em estática e dinâmica. Diagnóstico preciso, sem chute." />
        <ServiceRow num="04" mark="•" title="Órteses & calçados ortopédicos" blurb="Prescrição e adaptação de órteses, AFOs, sandálias terapêuticas e calçados sob medida para alterações estruturais." />
        <ServiceRow num="05" mark="•" title="Atendimento esportivo" blurb="Corredores, triatletas e amadores: avaliação biomecânica voltada à prevenção de lesões e retorno seguro à atividade." />
        <ServiceRow num="06" mark="•" title="Atendimento infantil" blurb="Acompanhamento do desenvolvimento do pé pediátrico — pé chato, pé cavo, marcha em rotação interna, pés tortos congênitos." />
        <div style={{ borderTop: `1px solid ${A_RULE}` }} />
      </div>
    </section>

    {/* JOURNEY */}
    <section style={{ padding: '120px 64px', background: A_INK, color: A_CREAM }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80 }}>
        <div>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: A_CREAM_DEEP,
          }}><span style={{ width: 18, height: 1, background: A_CREAM_DEEP }}/> Como funciona</span>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontSize: 64, fontWeight: 400,
            margin: '20px 0 32px', letterSpacing: '-0.015em', lineHeight: 1, color: A_CREAM,
          }}>
            Uma jornada<br/>
            <em style={{ color: '#E8A8C7' }}>sem atalhos.</em>
          </h2>
          <p style={{ fontSize: 14, lineHeight: 1.75, color: A_CREAM_DEEP, maxWidth: 380 }}>
            O caminho do diagnóstico ao alívio é metódico. Mostramos cada passo para que você
            saiba exatamente o que esperar.
          </p>
        </div>
        <div>
          {[
            ['Agendamento', 'WhatsApp, telefone ou formulário online. Confirmamos horário e enviamos orientações em até 1 dia útil.'],
            ['Avaliação clínica', 'Conversa, exame físico, leitura de imagens e mapeamento da pisada — 60 minutos dedicados.'],
            ['Plano terapêutico', 'Indicação personalizada: palmilha, órtese, fisioterapia ou conduta cirúrgica quando necessário.'],
            ['Acompanhamento', 'Retornos programados para ajustes finos. Cada palmilha tem garantia de adaptação.'],
          ].map(([t, b], i) => (
            <div key={t} style={{
              borderTop: `1px solid ${A_INK_SOFT}`, padding: '28px 0',
              display: 'grid', gridTemplateColumns: '60px 1fr', gap: 24,
            }}>
              <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 28, color: '#E8A8C7' }}>
                0{i + 1}
              </div>
              <div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontSize: 26, fontStyle: 'italic', color: A_CREAM }}>{t}</div>
                <div style={{ fontSize: 13, color: A_CREAM_DEEP, marginTop: 8, lineHeight: 1.65 }}>{b}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* QUOTE / EDITORIAL */}
    <section style={{ padding: '120px 64px', textAlign: 'center', background: A_CREAM_DEEP }}>
      <div style={{ maxWidth: 820, margin: '0 auto' }}>
        <Tag>Palavra da equipe</Tag>
        <blockquote style={{
          fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
          fontSize: 52, lineHeight: 1.18, fontWeight: 400, color: A_INK,
          margin: '36px 0 0', letterSpacing: '-0.01em',
        }}>
          "O pé carrega o corpo inteiro. Tratá‑lo bem é uma decisão que reverbera no joelho,
          no quadril, na coluna — <span style={{ color: A_BRAND }}>e na sua disposição para o dia.</span>"
        </blockquote>
        <div style={{ marginTop: 36, fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: A_INK_SOFT }}>
          Equipe Máxxima · Campo Belo
        </div>
      </div>
    </section>

    {/* CONTACT */}
    <section style={{ padding: '120px 64px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64 }}>
        <div>
          <Tag>Agendamento</Tag>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontSize: 72, fontWeight: 400,
            margin: '20px 0 0', lineHeight: 1, letterSpacing: '-0.015em',
          }}>
            Quando você<br/>
            <em style={{ color: A_BRAND }}>quiser começar.</em>
          </h2>
          <p style={{ marginTop: 28, fontSize: 14, color: A_INK_SOFT, lineHeight: 1.7, maxWidth: 420 }}>
            Três caminhos. O mesmo cuidado em qualquer um deles. Respondemos em até 24h úteis.
          </p>
          <div style={{ marginTop: 48, display: 'flex', flexDirection: 'column', gap: 0 }}>
            {[
              ['WhatsApp', '(11) 9 0000-0000', 'Resposta em minutos, horário comercial'],
              ['Telefone', '(11) 0000-0000', 'Seg a sex, 8h às 19h · sáb 8h às 13h'],
              ['Endereço', 'Rua Exemplo, 000 — Campo Belo, SP', 'Estacionamento conveniado a 50m'],
              ['Convênios', 'Atendemos os principais', 'Consulte a lista atualizada com a recepção'],
            ].map(([k, v, sub]) => (
              <div key={k} style={{
                display: 'grid', gridTemplateColumns: '120px 1fr',
                padding: '24px 0', borderTop: `1px solid ${A_RULE}`, alignItems: 'baseline',
              }}>
                <div style={{ fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', color: A_INK_SOFT }}>{k}</div>
                <div>
                  <div style={{ fontFamily: '"Cormorant Garamond", serif', fontSize: 22, fontStyle: 'italic', color: A_INK }}>{v}</div>
                  <div style={{ fontSize: 12, color: A_INK_SOFT, marginTop: 4 }}>{sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div style={{ background: A_CREAM_DEEP, padding: 40, border: `1px solid ${A_RULE}` }}>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontSize: 28, fontStyle: 'italic', color: A_INK }}>
              Formulário de contato
            </div>
            <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 18 }}>
              {[
                ['Nome completo', 'Como prefere ser chamado'],
                ['E-mail', 'voce@exemplo.com'],
                ['Telefone / WhatsApp', '(00) 0 0000-0000'],
              ].map(([l, p]) => (
                <label key={l} style={{ display: 'block' }}>
                  <div style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: A_INK_SOFT, marginBottom: 8 }}>{l}</div>
                  <div style={{
                    height: 40, background: 'transparent', borderBottom: `1px solid ${A_INK_SOFT}`,
                    color: A_INK_SOFT, fontSize: 13, paddingTop: 8,
                  }}>{p}</div>
                </label>
              ))}
              <label>
                <div style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: A_INK_SOFT, marginBottom: 8 }}>Motivo da consulta</div>
                <div style={{
                  height: 88, borderBottom: `1px solid ${A_INK_SOFT}`,
                  color: A_INK_SOFT, fontSize: 13, paddingTop: 8,
                }}>Conte brevemente o que está incomodando…</div>
              </label>
            </div>
            <button style={{
              marginTop: 32, width: '100%', background: A_INK, color: A_CREAM,
              border: 'none', padding: '18px', fontSize: 11, letterSpacing: '0.24em',
              textTransform: 'uppercase', cursor: 'pointer',
            }}>Solicitar agendamento →</button>
          </div>
          <div style={{ marginTop: 24 }}>
            <Placeholder h={220} label="Mapa — Campo Belo, SP" tone="warm" />
          </div>
        </div>
      </div>
    </section>

    {/* FOOTER */}
    <footer style={{
      padding: '64px 64px 40px', background: A_INK, color: A_CREAM,
      display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48,
    }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, background: A_BRAND, position: 'relative' }}>
            <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0 }}>
              <path d="M 48 22 Q 56 26 54 38 Q 50 50 46 60 Q 44 72 50 82 L 38 82 Q 32 74 34 62 Q 38 50 42 38 Q 44 28 48 22 Z" fill="#fff"/>
            </svg>
          </div>
          <div>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 26, color: A_CREAM }}>máxxima</div>
            <div style={{ fontSize: 9, letterSpacing: '0.32em', color: A_CREAM_DEEP, marginTop: 2 }}>ORTOPEDIA</div>
          </div>
        </div>
        <p style={{ fontSize: 12, color: A_CREAM_DEEP, marginTop: 24, maxWidth: 320, lineHeight: 1.7 }}>
          Clínica dedicada exclusivamente ao pé e tornozelo. Campo Belo, São Paulo.
        </p>
      </div>
      {[
        ['Navegar', ['A clínica', 'Tratamentos', 'Jornada', 'Equipe', 'Convênios']],
        ['Contato', ['WhatsApp', 'Telefone', 'E-mail', 'Endereço']],
        ['Sociais', ['Instagram', 'Doctoralia', 'Google']],
      ].map(([t, items]) => (
        <div key={t}>
          <div style={{ fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', color: A_CREAM_DEEP, marginBottom: 18 }}>{t}</div>
          {items.map(i => <div key={i} style={{ fontSize: 13, marginBottom: 8, color: A_CREAM }}>{i}</div>)}
        </div>
      ))}
      <div style={{
        gridColumn: '1 / -1', marginTop: 24, paddingTop: 24, borderTop: `1px solid ${A_INK_SOFT}`,
        display: 'flex', justifyContent: 'space-between', fontSize: 10,
        letterSpacing: '0.22em', textTransform: 'uppercase', color: A_CREAM_DEEP,
      }}>
        <span>© 2026 Máxxima Ortopedia</span>
        <span>Site em construção — versão A</span>
      </div>
    </footer>
  </div>
);

window.VariationA = VariationA;
