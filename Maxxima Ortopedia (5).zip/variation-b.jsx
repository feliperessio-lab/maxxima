/* global React */

const B_BRAND = '#A8226B';
const B_BRAND_DEEP = '#6E0E44';
const B_BRAND_PALE = '#F5E3EC';
const B_INK = '#15100E';
const B_INK_SOFT = '#4A413E';
const B_PAPER = '#FFFFFF';
const B_PAPER_WARM = '#FBF7F2';
const B_RULE = '#E8DFD2';

// Brand-tinted placeholder (variation B leans into magenta blocks)
const BPlaceholder = ({ h = 420, label, tone = 'magenta' }) => {
  const palettes = {
    magenta: ['#A8226B', '#6E0E44'],
    pale: ['#F5E3EC', '#E5C9D6'],
    warm: ['#E8DAC4', '#D8C4A8'],
    ink: ['#2A1F1C', '#15100E'],
  };
  const [a, b] = palettes[tone];
  return (
    <div style={{
      position: 'relative', height: h,
      background: `linear-gradient(160deg, ${a} 0%, ${b} 100%)`,
      overflow: 'hidden', color: tone === 'pale' || tone === 'warm' ? '#15100E' : '#FBF7F2',
    }}>
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.18,
        backgroundImage: 'radial-gradient(circle at 30% 40%, rgba(255,255,255,0.4) 0%, transparent 50%)',
      }} />
      <div style={{
        position: 'absolute', top: 20, left: 22,
        fontFamily: '"Manrope", sans-serif', fontSize: 10, letterSpacing: '0.22em',
        textTransform: 'uppercase', opacity: 0.7,
      }}>{label}</div>
    </div>
  );
};

const BLabel = ({ children, color = B_BRAND }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 10,
    fontFamily: '"Manrope", sans-serif', fontSize: 11, letterSpacing: '0.28em',
    textTransform: 'uppercase', color, fontWeight: 600,
  }}>
    <span style={{ width: 8, height: 8, background: color, borderRadius: '50%' }} />
    {children}
  </span>
);

const VariationB = () => (
  <div style={{
    width: 1280, background: B_PAPER, color: B_INK,
    fontFamily: '"Manrope", sans-serif', fontSize: 14, lineHeight: 1.5,
  }}>
    {/* NAV — sits on white */}
    <header style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '24px 56px', position: 'relative', zIndex: 2,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 32, height: 32, background: B_BRAND, position: 'relative' }}>
          <svg viewBox="0 0 100 100" style={{ position: 'absolute', inset: 0 }}>
            <path d="M 48 22 Q 56 26 54 38 Q 50 50 46 60 Q 44 72 50 82 L 38 82 Q 32 74 34 62 Q 38 50 42 38 Q 44 28 48 22 Z" fill="#fff"/>
          </svg>
        </div>
        <div style={{ lineHeight: 1 }}>
          <div style={{
            fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
            fontSize: 24, color: B_BRAND, fontWeight: 500,
          }}>máxxima</div>
          <div style={{ fontSize: 9, letterSpacing: '0.32em', color: B_INK_SOFT, marginTop: 2 }}>ORTOPEDIA</div>
        </div>
      </div>
      <nav style={{ display: 'flex', gap: 32, fontSize: 12, fontWeight: 500 }}>
        {['Clínica', 'Tratamentos', 'Equipe', 'Jornada', 'Contato'].map(n => (
          <a key={n} style={{ color: B_INK }}>{n}</a>
        ))}
      </nav>
      <a style={{
        background: B_BRAND, color: '#fff', padding: '12px 22px', borderRadius: 999,
        fontSize: 12, fontWeight: 600, letterSpacing: '0.04em',
      }}>Agendar →</a>
    </header>

    {/* HERO — full bleed magenta block echoing the logo composition */}
    <section style={{
      margin: '0 56px', display: 'grid', gridTemplateColumns: '1fr 1fr',
      gap: 0, minHeight: 640,
    }}>
      {/* Left: dark text on warm paper */}
      <div style={{ padding: '64px 56px 64px 0', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          <BLabel>Ortopedia · Pé e tornozelo</BLabel>
          <h1 style={{
            fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
            fontSize: 96, lineHeight: 0.94, letterSpacing: '-0.02em',
            margin: '24px 0 0',
          }}>
            O cuidado que <em style={{ color: B_BRAND }}>seus&nbsp;pés</em><br/>
            esperam<br/>
            há <em style={{ color: B_BRAND }}>anos.</em>
          </h1>
          <p style={{
            marginTop: 28, fontSize: 16, lineHeight: 1.65, color: B_INK_SOFT, maxWidth: 440,
          }}>
            Clínica especializada exclusivamente em pés e tornozelos. Diagnóstico baropodométrico,
            palmilhas sob medida e tratamento ortopédico de excelência, em Campo Belo.
          </p>
        </div>
        <div>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginTop: 40 }}>
            <a style={{
              background: B_INK, color: '#fff', padding: '18px 32px', borderRadius: 999,
              fontSize: 13, fontWeight: 600, display: 'inline-flex', gap: 10, alignItems: 'center',
            }}><span style={{
              width: 18, height: 18, background: '#25D366', borderRadius: '50%',
              display: 'inline-block',
            }}/> WhatsApp · Agendar consulta</a>
            <a style={{
              padding: '18px 22px', fontSize: 13, fontWeight: 500,
              color: B_INK, border: `1px solid ${B_INK}`, borderRadius: 999,
            }}>(11) 0000-0000</a>
          </div>
          <div style={{ display: 'flex', gap: 28, marginTop: 36 }}>
            {['Doctoralia 4.9 ★', '600+ pacientes/ano', 'Campo Belo · SP'].map(t => (
              <div key={t} style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: B_INK_SOFT, fontWeight: 600 }}>{t}</div>
            ))}
          </div>
        </div>
      </div>

      {/* Right: the iconic magenta block from the logo, blown up */}
      <div style={{
        background: B_BRAND, position: 'relative', overflow: 'hidden',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {/* The foot mark, scaled up */}
        <svg viewBox="0 0 100 100" style={{ width: '64%', height: '64%' }}>
          <path d="M 48 18 Q 60 22 56 38 Q 50 52 46 64 Q 42 76 50 88 L 36 88 Q 28 78 32 64 Q 38 50 42 36 Q 44 24 48 18 Z" fill="#fff"/>
        </svg>
        {/* Editorial caption */}
        <div style={{
          position: 'absolute', bottom: 28, left: 28, right: 28,
          display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
          color: '#fff',
        }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', opacity: 0.7 }}>Símbolo</div>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 22, marginTop: 6 }}>
              O passo elevado
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', opacity: 0.7 }}>Desde</div>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 22, marginTop: 6 }}>2008</div>
          </div>
        </div>
      </div>
    </section>

    {/* TICKER */}
    <section style={{ padding: '32px 0', borderTop: `1px solid ${B_RULE}`, borderBottom: `1px solid ${B_RULE}`, marginTop: 64, overflow: 'hidden' }}>
      <div style={{ display: 'flex', gap: 48, padding: '0 56px', alignItems: 'center', whiteSpace: 'nowrap' }}>
        {['Fascite plantar', '·', 'Esporão de calcâneo', '·', 'Joanetes', '·', 'Pé chato', '·', 'Pé cavo', '·', 'Neuroma de Morton', '·', 'Pé diabético', '·', 'Tendinite de Aquiles', '·', 'Pé do corredor'].map((t, i) => (
          <span key={i} style={{
            fontFamily: t === '·' ? 'serif' : '"Cormorant Garamond", serif',
            fontStyle: 'italic', fontSize: t === '·' ? 28 : 24,
            color: i % 4 === 0 ? B_BRAND : B_INK,
          }}>{t}</span>
        ))}
      </div>
    </section>

    {/* SERVICES — magazine grid */}
    <section style={{ padding: '120px 56px', background: B_PAPER_WARM }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 56, alignItems: 'flex-end', marginBottom: 56 }}>
        <BLabel>Tratamentos</BLabel>
        <h2 style={{
          gridColumn: '2 / 4',
          fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
          fontSize: 72, lineHeight: 0.98, letterSpacing: '-0.02em', margin: 0,
        }}>
          Tudo o que <em style={{ color: B_BRAND }}>seu pé</em><br/>
          pode precisar — e nada mais.
        </h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 24 }}>
        {[
          { t: 'Consulta ortopédica', n: '01', desc: 'Avaliação clínica completa: anamnese, exame funcional, palpação, leitura de imagens.', tone: 'magenta', big: true },
          { t: 'Palmilha posturais', n: '02', desc: 'Personalizadas a partir da sua pisada. Corrigem apoio e aliviam dor.', tone: 'pale' },
          { t: 'Avaliação baropodométrica', n: '03', desc: 'Mapeamento digital da pressão plantar — estática e dinâmica.', tone: 'warm' },
          { t: 'Órteses & calçados', n: '04', desc: 'Prescrição de órteses e calçados sob medida para correções estruturais.', tone: 'pale' },
          { t: 'Atendimento esportivo', n: '05', desc: 'Corredores e amadores: prevenção de lesões e retorno seguro à atividade.', tone: 'warm' },
          { t: 'Atendimento infantil', n: '06', desc: 'Desenvolvimento do pé pediátrico: pé chato, cavo, marcha em rotação.', tone: 'magenta' },
        ].map((s, i) => {
          const dark = s.tone === 'magenta';
          const bg = dark ? B_BRAND : s.tone === 'pale' ? B_BRAND_PALE : '#EFE5D4';
          const fg = dark ? '#fff' : B_INK;
          return (
            <div key={s.n} style={{
              background: bg, color: fg, padding: 32,
              minHeight: 280, display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
              gridColumn: s.big ? 'span 1' : undefined,
            }}>
              <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 18, opacity: 0.6 }}>
                — {s.n}
              </div>
              <div>
                <div style={{
                  fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
                  fontSize: 32, lineHeight: 1.08, fontWeight: 500, marginBottom: 14,
                }}>{s.t}</div>
                <div style={{ fontSize: 13, lineHeight: 1.65, opacity: dark ? 0.9 : 0.75 }}>{s.desc}</div>
                <div style={{
                  marginTop: 22, fontSize: 10, letterSpacing: '0.28em',
                  textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 8,
                  fontWeight: 600,
                }}>
                  Saber mais
                  <span style={{ fontSize: 14 }}>→</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>

    {/* THE DOCTOR — editorial split */}
    <section style={{ padding: '120px 56px', background: B_PAPER }}>
      <div style={{ display: 'grid', gridTemplateColumns: '5fr 6fr', gap: 56, alignItems: 'center' }}>
        <div style={{ position: 'relative' }}>
          <img
            src="assets/dra-cibele-ressio.jpg"
            alt="Dra. Cibele Réssio — médica responsável"
            style={{ width: '100%', height: 620, objectFit: 'cover', objectPosition: 'center top', display: 'block' }}
          />
          <div style={{
            position: 'absolute', bottom: 24, right: 24,
            background: B_BRAND, color: '#fff', padding: '20px 24px',
            maxWidth: 240,
          }}>
            <div style={{ fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', opacity: 0.7 }}>Responsável técnica</div>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 26, marginTop: 8, lineHeight: 1.1 }}>
              Dra. Cibele Réssio
            </div>
            <div style={{ fontSize: 11, marginTop: 8, opacity: 0.9, lineHeight: 1.5 }}>CRM-SP 72.981<br/>RQE 104.807</div>
          </div>
        </div>
        <div>
          <BLabel>A equipe</BLabel>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
            fontSize: 64, lineHeight: 1, margin: '20px 0 28px', letterSpacing: '-0.015em',
          }}>
            Uma carreira inteira <em style={{ color: B_BRAND }}>dedicada à mesma articulação.</em>
          </h2>
          <p style={{ fontSize: 15, lineHeight: 1.75, color: B_INK_SOFT, maxWidth: 520 }}>
            Especialização em cirurgia do pé e tornozelo pela SBOT. Mais de 15 anos
            atendendo pacientes em São Paulo. Acreditamos que profundidade vence amplitude —
            quem trata só pé, trata melhor.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginTop: 40 }}>
            {[
              ['Formação', 'FMUSP'],
              ['Especialização', 'SBOT — Cirurgia do pé'],
              ['Áreas', 'Adulto, infantil, esportivo'],
              ['Publicações', '12 artigos em periódicos'],
            ].map(([k, v]) => (
              <div key={k} style={{ borderTop: `1px solid ${B_RULE}`, paddingTop: 14 }}>
                <div style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: B_INK_SOFT }}>{k}</div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 22, marginTop: 6 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>

    {/* JOURNEY — magenta band */}
    <section style={{ padding: '100px 56px', background: B_BRAND, color: '#fff' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 60 }}>
        <BLabel color="#F5E3EC">Jornada do paciente</BLabel>
        <h2 style={{
          fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
          fontSize: 72, letterSpacing: '-0.02em', lineHeight: 0.98, margin: 0, color: '#fff',
          textAlign: 'right', maxWidth: 720,
        }}>
          Da primeira <em>mensagem</em><br/>
          ao último <em>retorno.</em>
        </h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }}>
        {[
          ['01', 'Agendamento', 'WhatsApp, telefone ou formulário. Resposta em até 1 dia útil.'],
          ['02', 'Avaliação', 'Consulta de 60min com exame físico e mapeamento da pisada.'],
          ['03', 'Plano terapêutico', 'Indicação personalizada — palmilha, órtese, fisio ou cirurgia.'],
          ['04', 'Acompanhamento', 'Retornos programados. Garantia de adaptação para palmilhas.'],
        ].map(([n, t, d]) => (
          <div key={n} style={{ borderTop: `1px solid rgba(255,255,255,0.3)`, paddingTop: 24 }}>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 56, lineHeight: 1, color: '#F5E3EC' }}>{n}</div>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 26, marginTop: 16 }}>{t}</div>
            <div style={{ fontSize: 13, marginTop: 12, lineHeight: 1.65, opacity: 0.85 }}>{d}</div>
          </div>
        ))}
      </div>
    </section>

    {/* CONDITIONS GRID */}
    <section style={{ padding: '120px 56px', background: B_PAPER_WARM }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 80, alignItems: 'flex-start' }}>
        <div style={{ position: 'sticky', top: 40 }}>
          <BLabel>Condições que tratamos</BLabel>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
            fontSize: 56, lineHeight: 1, margin: '20px 0 0', letterSpacing: '-0.015em',
          }}>
            Algumas das <em style={{ color: B_BRAND }}>queixas</em> que escutamos toda&nbsp;semana.
          </h2>
          <p style={{ fontSize: 14, color: B_INK_SOFT, marginTop: 20, lineHeight: 1.7 }}>
            Se a sua não está aqui — provavelmente também tratamos. Pergunte pelo WhatsApp.
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0 }}>
          {[
            ['Fascite plantar', 'Dor no calcanhar ao acordar'],
            ['Esporão de calcâneo', 'Pontada plantar persistente'],
            ['Joanete (Hálux Valgo)', 'Deformidade na base do dedão'],
            ['Pé chato (plano)', 'Adulto e infantil'],
            ['Pé cavo', 'Arco excessivamente elevado'],
            ['Neuroma de Morton', 'Queimação entre os dedos'],
            ['Tendinite de Aquiles', 'Dor posterior do tornozelo'],
            ['Pé diabético', 'Cuidado preventivo e curativo'],
            ['Entorse de tornozelo', 'Agudo e recidivante'],
            ['Pé do corredor', 'Lesão por uso excessivo'],
            ['Unha encravada', 'Tratamento clínico e cirúrgico'],
            ['Metatarsalgia', 'Dor na planta anterior'],
          ].map(([t, d]) => (
            <div key={t} style={{
              padding: '20px 0', borderTop: `1px solid ${B_RULE}`,
            }}>
              <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 26, color: B_INK }}>{t}</div>
              <div style={{ fontSize: 12, color: B_INK_SOFT, marginTop: 4 }}>{d}</div>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* CONTACT — high contrast finale */}
    <section style={{ padding: '120px 56px', background: B_INK, color: '#fff' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80 }}>
        <div>
          <BLabel color="#F5E3EC">Agendamento</BLabel>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
            fontSize: 84, lineHeight: 0.95, letterSpacing: '-0.02em', margin: '20px 0 0',
          }}>
            Vamos cuidar<br/>
            <em style={{ color: '#F5A8D0' }}>do seu passo.</em>
          </h2>
          <p style={{ fontSize: 15, lineHeight: 1.7, color: '#D4C9C3', maxWidth: 440, marginTop: 28 }}>
            Três caminhos para chegar até nós. Atendemos os principais convênios e também consultas particulares.
          </p>
          <div style={{ marginTop: 48, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <a style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: B_BRAND, color: '#fff', padding: '24px 28px', borderRadius: 8,
            }}>
              <div>
                <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', opacity: 0.7 }}>WhatsApp</div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 32, marginTop: 4 }}>(11) 9 0000-0000</div>
              </div>
              <span style={{ fontSize: 22 }}>→</span>
            </a>
            <a style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: 'transparent', color: '#fff', padding: '24px 28px',
              borderRadius: 8, border: '1px solid rgba(255,255,255,0.2)',
            }}>
              <div>
                <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', opacity: 0.7 }}>Telefone</div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 32, marginTop: 4 }}>(11) 0000-0000</div>
              </div>
              <span style={{ fontSize: 22 }}>→</span>
            </a>
            <a style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: 'transparent', color: '#fff', padding: '24px 28px',
              borderRadius: 8, border: '1px solid rgba(255,255,255,0.2)',
            }}>
              <div>
                <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', opacity: 0.7 }}>Formulário</div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 32, marginTop: 4 }}>Receba retorno em 24h</div>
              </div>
              <span style={{ fontSize: 22 }}>→</span>
            </a>
          </div>
        </div>
        <div>
          <BPlaceholder h={380} label="Mapa — Campo Belo, SP" tone="ink" />
          <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            {[
              ['Endereço', 'Rua Exemplo, 000\nCampo Belo · São Paulo · SP\nCEP 00000-000'],
              ['Horário', 'Seg a Sex · 8h às 19h\nSábado · 8h às 13h\nDomingo · fechado'],
              ['Convênios', 'Bradesco Saúde, SulAmérica,\nAmil, Porto Seguro, Omint\n+ consultas particulares'],
              ['Estacionamento', 'Conveniado a 50m\nValet disponível mediante\nagendamento prévio'],
            ].map(([k, v]) => (
              <div key={k} style={{ borderTop: '1px solid rgba(255,255,255,0.2)', paddingTop: 16 }}>
                <div style={{ fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', color: '#F5A8D0' }}>{k}</div>
                <div style={{ fontSize: 12, color: '#D4C9C3', marginTop: 8, lineHeight: 1.75, whiteSpace: 'pre-line' }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>

    {/* FOOTER */}
    <footer style={{
      padding: '40px 56px', background: B_INK, color: '#D4C9C3',
      borderTop: '1px solid rgba(255,255,255,0.1)',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ width: 24, height: 24, background: B_BRAND }} />
        <span>© 2026 Máxxima Ortopedia</span>
      </div>
      <div style={{ display: 'flex', gap: 24 }}>
        <span>Instagram</span>
        <span>Doctoralia</span>
        <span>Google</span>
        <span>Política de privacidade</span>
      </div>
    </footer>
  </div>
);

window.VariationB = VariationB;
