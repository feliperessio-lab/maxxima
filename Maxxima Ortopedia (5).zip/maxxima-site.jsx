/* global React */
const { useState, useEffect, useRef } = React;

// ─── Brand tokens (driven by Tweaks) ──────────────────────────────────────
const PALETTES = {
  classic: { brand: '#A8226B', deep: '#6E0E44', pale: '#F5E3EC', pink: '#F5A8D0' }, // refined logo magenta
  vivid: { brand: '#BD0768', deep: '#7A0344', pale: '#FBE0EE', pink: '#F590C2' }, // exact logo magenta
  wine: { brand: '#8A1452', deep: '#530A33', pale: '#EDDAE2', pink: '#D784A5' } // deeper wine
};

const INK = '#15100E';
const INK_SOFT = '#4A413E';
const PAPER = '#FFFFFF';
const PAPER_WARM = '#FBF7F2';
const RULE = '#E8DFD2';

// Foot mark — abstracted from logo (used on dark surfaces where the full color logo would not read)
const FootMark = ({ size = 32, fg = '#fff', bg = '#A8226B', radius = 0 }) =>
<div style={{ width: size, height: size, background: bg, position: 'relative', borderRadius: radius, flexShrink: 0 }}>
    <img src="assets/maxxima-foot-white.png" alt="" style={{
    position: 'absolute', inset: '12% 18%', width: '64%', height: '76%',
    objectFit: 'contain', filter: fg === '#fff' ? 'none' : 'invert(1)'
  }} />
  </div>;


const Wordmark = ({ brand, size = 'sm' }) => {
  const h = size === 'lg' ? 56 : 44;
  return (
    <img src="assets/maxxima-logo-trim.png" alt="Máxxima Ortopedia" style={{ height: h, width: 'auto', display: 'block' }} />);

};

// Strict scroll reveal — no fail-open, only fires when element is genuinely
// in view. Used for hero imagery that should feel like it "lands" on scroll.
const ScrollReveal = ({ children, style, threshold = 0.25 }) => {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    if (typeof IntersectionObserver === 'undefined') {setVisible(true);return;}
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {setVisible(true);io.disconnect();}
      });
    }, { rootMargin: '0px 0px -15% 0px', threshold });
    io.observe(ref.current);
    return () => io.disconnect();
  }, [threshold]);
  return (
    <div ref={ref} style={{
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0) scale(1)' : 'translateY(60px) scale(0.96)',
      transition: 'opacity 1100ms cubic-bezier(.2,.7,.2,1), transform 1200ms cubic-bezier(.2,.7,.2,1)',
      ...style
    }}>{children}</div>);
};

// Reveal on scroll — with fail-open fallback so content never gets stuck hidden
const Reveal = ({ children, delay = 0, style }) => {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!ref.current) {setVisible(true);return;}
    if (typeof IntersectionObserver === 'undefined') {setVisible(true);return;}
    let done = false;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting && !done) {done = true;setVisible(true);io.disconnect();}
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.01 });
    io.observe(ref.current);
    // Fail-open: if IO hasn't fired in 600ms, just show. Covers preview iframes,
    // print, and any environment where IO is unreliable.
    const t = setTimeout(() => {if (!done) {done = true;setVisible(true);io.disconnect();}}, 600);
    return () => {clearTimeout(t);io.disconnect();};
  }, []);
  return (
    <div ref={ref} style={{
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0)' : 'translateY(24px)',
      transition: `opacity 900ms cubic-bezier(.2,.7,.2,1) ${delay}ms, transform 900ms cubic-bezier(.2,.7,.2,1) ${delay}ms`,
      ...style
    }}>{children}</div>);

};

const Label = ({ children, color, dot = true }) =>
<span style={{
  display: 'inline-flex', alignItems: 'center', gap: 10,
  fontFamily: '"Manrope", sans-serif', fontSize: 11, letterSpacing: '0.28em',
  textTransform: 'uppercase', color, fontWeight: 600
}}>
    {dot && <span style={{ ...{ width: 7, height: 7, background: color, borderRadius: '50%' }, background: "rgb(252, 252, 252)" }} />}
    {children}
  </span>;


// Placeholder — magenta-tinted gradient blocks (no fake imagery)
const Img = ({ h = 420, label, tone = 'magenta', P, ratio, style }) => {
  const palettes = {
    magenta: [P.brand, P.deep],
    pale: [P.pale, P.pink],
    warm: ['#E8DAC4', '#D8C4A8'],
    ink: ['#2A1F1C', '#15100E'],
    paper: ['#FBF7F2', '#EFE5D4']
  };
  const [a, b] = palettes[tone];
  const dark = tone === 'magenta' || tone === 'ink';
  return (
    <div style={{
      position: 'relative', height: h, aspectRatio: ratio,
      background: `linear-gradient(160deg, ${a} 0%, ${b} 100%)`,
      overflow: 'hidden', color: dark ? '#FBF7F2' : INK,
      ...style
    }}>
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.18,
        backgroundImage: 'radial-gradient(circle at 30% 35%, rgba(255,255,255,0.45) 0%, transparent 55%)'
      }} />
      <div style={{
        position: 'absolute', top: 18, left: 20,
        fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase',
        opacity: 0.65, fontWeight: 500
      }}>{label}</div>
    </div>);

};

// ─── SECTIONS ──────────────────────────────────────────────────────────────

const Nav = ({ P }) => {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 10,
      background: scrolled ? 'rgba(255,255,255,0.92)' : 'transparent',
      backdropFilter: scrolled ? 'blur(20px) saturate(180%)' : 'none',
      WebkitBackdropFilter: scrolled ? 'blur(20px) saturate(180%)' : 'none',
      borderBottom: scrolled ? `1px solid ${RULE}` : '1px solid transparent',
      transition: 'all 300ms ease'
    }}>
      <div className="container" style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 56px'
      }}>
        <Wordmark brand={P.brand} />
        <nav className="nav-links" style={{ display: 'flex', gap: 36, fontSize: 13, fontWeight: 500 }}>
          {[['#clinica', 'A Clínica'], ['#dra-cibele', 'A Dra.'], ['#tratamentos', 'Tratamentos'], ['#producao', 'Produção'], ['#condicoes', 'Condições'], ['#contato', 'Contato']].map(([href, label]) =>
          <a key={href} href={href} style={{ color: INK, transition: 'color 200ms', cursor: 'pointer' }}>{label}</a>
          )}
        </nav>
        <a href="#contato" style={{
          background: P.brand, color: '#fff', padding: '12px 22px', borderRadius: 999,
          fontSize: 12, fontWeight: 600, letterSpacing: '0.04em', cursor: 'pointer',
          transition: 'background 200ms'
        }}>Agendar →</a>
      </div>
    </header>);

};

const Hero = ({ P, density }) =>
<section style={{ padding: '0 56px' }} className="hero">
    <div style={{
    display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0,
    minHeight: density === 'compact' ? 560 : 680
  }} className="hero-grid">
      {/* Left text block */}
      <div style={{
      padding: '64px 56px 64px 0',
      display: 'flex', flexDirection: 'column', justifyContent: 'space-between'
    }} className="hero-left">
        <Reveal>
          <Label color={P.brand}>Ortopedia · Pé e tornozelo</Label>
          <h1 style={{
          fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
          fontSize: 'clamp(56px, 7vw, 104px)', lineHeight: 0.94, letterSpacing: '-0.02em',
          margin: '24px 0 0', color: INK
        }}>
            O cuidado que <em style={{ color: P.brand, fontWeight: 500 }}>seus&nbsp;pés</em><br />
            esperam<br />
            há <em style={{ color: P.brand, fontWeight: 500 }}>anos.</em>
          </h1>
        </Reveal>
        <Reveal delay={200}>
          <p style={{
          marginTop: 32, fontSize: 16, lineHeight: 1.65, color: INK_SOFT, maxWidth: 460
        }}>
            Clínica especializada exclusivamente em pés e tornozelos. Diagnóstico baropodométrico,
            palmilhas sob medida e tratamento ortopédico de excelência, em Campo Belo.
          </p>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginTop: 40, flexWrap: 'wrap' }}>
            <a
            href="https://wa.me/5511917111144?text=Olá! Gostaria de agendar uma consulta na Máxxima Ortopedia."
            target="_blank"
            rel="noopener noreferrer"
            style={{
              background: INK, color: '#fff', padding: '18px 28px', borderRadius: 999,
              fontSize: 13, fontWeight: 600, display: 'inline-flex', gap: 12, alignItems: 'center',
              cursor: 'pointer', transition: 'transform 200ms'
            }}>
            
              <span style={{
              width: 18, height: 18, background: '#25D366', borderRadius: '50%',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center'
            }}>
                <svg viewBox="0 0 24 24" width="11" height="11" fill="#fff"><path d="M12 2C6.48 2 2 6.48 2 12c0 1.96.57 3.78 1.54 5.32L2 22l4.78-1.5C8.3 21.43 10.1 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm5.4 14.6c-.23.65-1.16 1.2-1.86 1.32-.48.07-1.1.13-3.13-.67-2.61-1.05-4.31-3.65-4.45-3.82-.13-.18-1.07-1.42-1.07-2.71 0-1.29.68-1.93.92-2.19.24-.27.52-.34.7-.34.18 0 .35.01.5.02.16.01.37-.06.58.44.23.55.78 1.93.85 2.07.07.14.12.31.02.49-.1.18-.15.29-.3.45-.14.16-.31.36-.43.48-.14.14-.29.29-.13.57.16.27.7 1.16 1.51 1.88 1.04.93 1.91 1.22 2.18 1.36.27.14.43.12.59-.07.16-.18.68-.8.86-1.07.18-.27.36-.22.6-.14.25.09 1.6.76 1.87.9.27.13.45.2.52.31.07.11.07.65-.16 1.3z" /></svg>
              </span>
              Agendar pelo WhatsApp
            </a>
          </div>
          <div style={{ display: 'flex', gap: 32, marginTop: 40, flexWrap: 'wrap' }}>
            {['Doctoralia 4.9 ★', '600+ pacientes/ano', 'Campo Belo · SP'].map((t) =>
          <div key={t} style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: INK_SOFT, fontWeight: 600 }}>{t}</div>
          )}
          </div>
        </Reveal>
      </div>

      {/* Right block — anatomical bones illustration on magenta (image background removed) */}
      <div style={{ ...{
        background: P.brand, position: 'relative', overflow: 'hidden',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        height: '100%', minHeight: 600,
        padding: '48px 32px'
      }, background: "rgb(253, 252, 253)" }}>
        <ScrollReveal threshold={0.35} style={{ width: '78%', maxHeight: '92%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img
          src="assets/maxxima-ossos-pe.png"
          alt="Ilustração anatômica dos ossos do pé e tornozelo"
          loading="lazy"
          style={{
            width: '100%', height: 'auto', maxHeight: '92vh',
            objectFit: 'contain', display: 'block'
          }} />
        </ScrollReveal>
      </div>
    </div>
  </section>;


const Ticker = ({ P }) => {
  const items = ['Fascite plantar', 'Esporão de calcâneo', 'Joanetes', 'Pé chato', 'Pé cavo', 'Neuroma de Morton', 'Pé diabético', 'Tendinite de Aquiles', 'Pé do corredor', 'Metatarsalgia', 'Entorse de tornozelo', 'Unha encravada'];
  const all = [...items, ...items];
  return (
    <section style={{
      borderTop: `1px solid ${RULE}`, borderBottom: `1px solid ${RULE}`,
      marginTop: 80, overflow: 'hidden', padding: '24px 0'
    }}>
      <div style={{
        display: 'flex', gap: 40, whiteSpace: 'nowrap', alignItems: 'center',
        animation: 'tickerScroll 48s linear infinite'
      }}>
        {all.map((t, i) =>
        <React.Fragment key={i}>
            <span style={{
            fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
            fontSize: 28, color: i % 4 === 0 ? P.brand : INK, fontWeight: 400
          }}>{t}</span>
            <span style={{ color: P.brand, fontSize: 24 }}>•</span>
          </React.Fragment>
        )}
      </div>
    </section>);

};

const Clinica = ({ P }) =>
<section id="clinica" style={{ padding: '120px 56px', background: PAPER }}>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 80 }} className="two-col">
      <div style={{ position: 'sticky', top: 100, alignSelf: 'flex-start' }}>
        <Reveal><Label color={P.brand}>A clínica</Label></Reveal>
      </div>
      <div>
        <Reveal>
          <h2 style={{
          fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
          fontSize: 'clamp(40px, 4.4vw, 64px)', lineHeight: 1.05, letterSpacing: '-0.015em',
          margin: 0
        }}>
            Acreditamos que o cuidado ortopédico do pé exige <em style={{ color: P.brand }}>tempo, escuta e instrumental preciso.</em>
          </h2>
        </Reveal>
        <Reveal delay={120}>
          <p style={{ fontSize: 16, lineHeight: 1.75, color: INK_SOFT, marginTop: 32, maxWidth: 640 }}>
            Construímos uma clínica de especialidade única — onde cada paciente é avaliado por
            quem dedicou a carreira inteira a esta articulação. Sem fila, sem corre-corre, sem chute.
          </p>
        </Reveal>
        <Reveal delay={200}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32, marginTop: 64 }} className="stats">
            {[
          ['16 anos', 'Dedicados a esta especialidade'],
          ['60 min', 'Duração média de uma consulta'],
          ['1 articulação', 'É só nisso que pensamos']].
          map(([n, d]) =>
          <div key={n} style={{ borderTop: `1px solid ${RULE}`, paddingTop: 20 }}>
                <div style={{
              fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
              fontSize: 48, color: P.brand, lineHeight: 1
            }}>{n}</div>
                <div style={{ fontSize: 13, color: INK_SOFT, marginTop: 12, lineHeight: 1.5 }}>{d}</div>
              </div>
          )}
          </div>
        </Reveal>
      </div>
    </div>
  </section>;


const Tratamentos = ({ P }) => {
  const items = [
  { t: 'Consulta ortopédica', n: '01', desc: 'Avaliação clínica completa: anamnese, exame funcional, palpação, leitura de imagens.', tone: 'magenta' },
  { t: 'Palmilha postural', n: '02', desc: 'Personalizadas a partir da sua pisada. Corrigem apoio e aliviam dor.', tone: 'pale' },
  { t: 'Avaliação baropodométrica', n: '03', desc: 'Mapeamento digital da pressão plantar — em estática e dinâmica.', tone: 'warm' },
  { t: 'Órteses & calçados', n: '04', desc: 'Prescrição de órteses e calçados sob medida para correções estruturais.', tone: 'pale' },
  { t: 'Atendimento esportivo', n: '05', desc: 'Corredores e amadores: prevenção de lesões e retorno seguro à atividade.', tone: 'warm' },
  { t: 'Atendimento infantil', n: '06', desc: 'Desenvolvimento do pé pediátrico: pé chato, cavo, marcha em rotação.', tone: 'magenta' }];

  return (
    <section id="tratamentos" style={{ padding: '120px 56px', background: PAPER_WARM }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 56, alignItems: 'flex-end', marginBottom: 56 }} className="two-col">
        <Reveal><Label color={P.brand}>Tratamentos</Label></Reveal>
        <Reveal delay={100}>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
            fontSize: 'clamp(40px, 5vw, 72px)', lineHeight: 0.98, letterSpacing: '-0.02em', margin: 0
          }}>
            Tudo o que <em style={{ color: P.brand }}>seu pé</em> pode precisar — e nada mais.
          </h2>
        </Reveal>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }} className="grid-3">
        {items.map((s, i) => {
          const dark = s.tone === 'magenta';
          const bg = dark ? P.brand : s.tone === 'pale' ? P.pale : '#EFE5D4';
          const fg = dark ? '#fff' : INK;
          return (
            <Reveal key={s.n} delay={i * 80}>
              <div style={{
                background: bg, color: fg, padding: 32,
                minHeight: 300, display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
                transition: 'transform 400ms ease', cursor: 'default'
              }}>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 20, opacity: 0.55 }}>— {s.n}</div>
                <div>
                  <div style={{
                    fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
                    fontSize: 34, lineHeight: 1.08, fontWeight: 500, marginBottom: 14
                  }}>{s.t}</div>
                  <div style={{ fontSize: 13, lineHeight: 1.65, opacity: dark ? 0.9 : 0.7 }}>{s.desc}</div>
                  <div style={{
                    marginTop: 24, fontSize: 10, letterSpacing: '0.28em',
                    textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 8,
                    fontWeight: 600
                  }}>
                    Saber mais
                    <span style={{ fontSize: 14 }}>→</span>
                  </div>
                </div>
              </div>
            </Reveal>);

        })}
      </div>
    </section>);

};

const Doutora = ({ P }) =>
<section id="dra-cibele" style={{ padding: '120px 56px', background: PAPER }}>
    <div style={{ display: 'grid', gridTemplateColumns: '5fr 6fr', gap: 80, alignItems: 'center', maxWidth: 1400, margin: '0 auto' }} className="two-col">
      {/* Portrait */}
      <ScrollReveal threshold={0.2}>
        <div style={{ position: 'relative' }}>
          <div style={{
          position: 'absolute', top: -28, left: -28, right: 28, bottom: 28,
          background: P.brand, opacity: 0.08, zIndex: 0
        }} />
          <img
          src="assets/dra-cibele-portrait.png"
          alt="Dra. Cibele Réssio"
          loading="lazy"
          style={{
            position: 'relative', zIndex: 1,
            width: '100%', height: 'auto', display: 'block',
            aspectRatio: '4 / 5', objectFit: 'cover', objectPosition: '50% 20%',
            filter: 'grayscale(8%) contrast(1.02)'
          }} />
          
          {/* Signature badge */}
          <div style={{
          position: 'absolute', zIndex: 2,
          right: -16, bottom: -16,
          background: '#fff', padding: '18px 22px',
          boxShadow: '0 18px 40px -22px rgba(0,0,0,0.35)',
          borderTop: `2px solid ${P.brand}`
        }}>
            <div style={{ fontSize: 9, letterSpacing: '0.28em', textTransform: 'uppercase', color: INK_SOFT, fontWeight: 600, marginBottom: 8 }}>
              Registros
            </div>
            <div style={{ display: 'flex', gap: 22, alignItems: 'baseline' }}>
              <div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 26, color: P.brand, lineHeight: 1 }}>72981</div>
                <div style={{ fontSize: 10, letterSpacing: '0.18em', color: INK_SOFT, marginTop: 4, fontWeight: 600 }}>CRM-SP</div>
              </div>
              <div style={{ width: 1, alignSelf: 'stretch', background: RULE }} />
              <div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 26, color: P.brand, lineHeight: 1 }}>104807</div>
                <div style={{ fontSize: 10, letterSpacing: '0.18em', color: INK_SOFT, marginTop: 4, fontWeight: 600 }}>RQE</div>
              </div>
            </div>
          </div>
        </div>
      </ScrollReveal>

      {/* Bio */}
      <div>
        <Reveal><Label color={P.brand}>Quem cuida de você</Label></Reveal>
        <Reveal delay={100}>
          <h2 style={{
          fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
          fontSize: 'clamp(44px, 4.8vw, 72px)', lineHeight: 1.02, letterSpacing: '-0.02em',
          margin: '20px 0 0'
        }}>
            Dra. <em style={{ color: P.brand }}>Cibele Réssio</em>
          </h2>
        </Reveal>
        <Reveal delay={160}>
          <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 22, color: INK_SOFT, marginTop: 14, letterSpacing: '0.01em' }}>
            Ortopedista especialista em medicina e cirurgia do pé e tornozelo
          </div>
        </Reveal>
        <Reveal delay={220}>
          <p style={{ fontSize: 16, lineHeight: 1.75, color: INK_SOFT, marginTop: 32, maxWidth: 560 }}>
            Formada pela Escola Paulista de Medicina (UNIFESP), com mestrado pela mesma
            instituição e mais de duas décadas dedicadas exclusivamente à articulação
            que sustenta o corpo inteiro. Autora e coautora de artigos publicados em
            periódicos brasileiros indexados.
          </p>
        </Reveal>
        <Reveal delay={280}>
          <div style={{ marginTop: 40, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, maxWidth: 520 }} className="grid-2">
            {[
          ['Formação', 'UNIFESP — Escola Paulista de Medicina'],
          ['Mestrado', 'Avaliação baropodométrica · UNIFESP'],
          ['Sociedades', 'SBOT · ABTPé · SICOT'],
          ['Aperfeiçoamento', 'EUA · Espanha · Argentina']].
          map(([k, v]) =>
          <div key={k} style={{ borderTop: `1px solid ${RULE}`, paddingTop: 14 }}>
                <div style={{ fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: P.brand, fontWeight: 600 }}>{k}</div>
                <div style={{ fontSize: 13, color: INK, marginTop: 8, lineHeight: 1.5 }}>{v}</div>
              </div>
          )}
          </div>
        </Reveal>
      </div>
    </div>
  </section>;


const Producao = ({ P }) => {
  // Artigos científicos — peer-reviewed, autoria ou coautoria de Cibele Réssio.
  // Ordem cronológica reversa (mais recente primeiro).
  const artigos = [
  {
    t: 'Artroplastia total de tornozelo: experiência brasileira com a prótese HINTEGRA',
    j: 'Revista Brasileira de Ortopedia',
    ref: '2010 · v. 45, n. 1, p. 92–100',
    role: 'Coautora',
    coa: 'Caio Nery, Túlio Diniz Fernandes, Mauro Luiz Fuchs, Alexandre Leme de Godoy Santos, Rafael Trevisan Ortiz',
    y: '2010',
    u: 'https://www.scielo.br/j/rbort/a/G5RpBb9dSCtvtwLdf7mFDFj/abstract/?lang=pt'
  },
  {
    t: 'Implante autólogo de condrócitos no tratamento das lesões osteocondrais do talo',
    j: 'Revista ABTPé',
    ref: '2010 · v. 4, n. 2',
    role: 'Coautora',
    coa: 'Caio Nery, Christiane Lambello, Inácio Asaumi',
    y: '2010',
    u: 'https://jfootankle.com/ABTPe/article/view/682'
  },
  {
    t: 'Avaliação radiográfica do hálux valgo: estudo populacional de novos parâmetros angulares',
    j: 'Acta Ortopédica Brasileira',
    ref: 'SciELO',
    role: 'Coautora',
    coa: 'Caio Augusto de Souza Nery, Alfonso Apostólico Netto, Márcio Benevento',
    y: '2001',
    u: 'https://www.scielo.br/j/aob/a/VRtH75fzNxzV8MfTS8bjQkK/?lang=pt'
  },
  {
    t: 'Avaliação baropodométrica da influência dos saltos altos em indivíduos normais',
    j: 'Dissertação de Mestrado · UNIFESP · Escola Paulista de Medicina',
    ref: 'Orientador: Prof. Dr. Caio Augusto de Souza Nery',
    role: 'Autora',
    coa: '',
    y: '1999',
    u: 'https://repositorio.unifesp.br/items/095ff70c-50cb-4de3-8620-30f812a9b2c3'
  }];

  // u: URL real do artigo (preencher quando disponível). Se vazio, cai em busca Google.
  const publicacoes = [
  { t: 'SOS Pés', v: 'Folha de São Paulo · Folha Equilíbrio', y: '2010', u: '' },
  { t: 'Clac-clac', v: 'Folha de São Paulo', y: '2010', u: '' },
  { t: 'A moda contra a Anatomia', v: 'Jornal da Escola', y: '2003', u: '' },
  { t: 'Pé para fora', v: 'Revista Marie Claire', y: '2003', u: '' },
  { t: 'Pezinho de anjo', v: 'Revista Criativa', y: '2002', u: '' },
  { t: 'Se seu corpo falasse…', v: 'Revista Cláudia', y: '2002', u: '' },
  { t: 'Prepare-se para encarar o dia seguinte ao Carnaval', v: 'Jornal Agora · com C. Nery', y: '2002', u: '' },
  { t: 'Receita para cair na folia e chegar inteiro na quarta-feira', v: 'Jornal da Paulista', y: '2002', u: '' },
  { t: 'Pés das brasileiras', v: 'Informe UNICEMP, Curitiba', y: '—', u: '' }];

  const linkFor = (p) => p.u ?
  p.u :
  `https://www.google.com/search?q=${encodeURIComponent(`"Cibele Réssio" "${p.t}" ${p.v}`)}`;
  const congressos = [
  { t: '26th SICOT Triennial World Congress', loc: 'Brasil', y: '2014' },
  { t: '46th Brazilian Congress of Orthopaedics and Traumatology', loc: 'Brasil', y: '2014' },
  { t: 'AAOS Annual Meeting', loc: 'Estados Unidos', y: '2008' },
  { t: 'AAOS Specialty Day · AOFAS', loc: 'Estados Unidos', y: '2008' },
  { t: 'AO Foot and Ankle Course', loc: 'Internacional', y: '2008' },
  { t: '3rd Joint Meeting · Int. Federation of Foot & Ankle Societies', loc: 'Internacional', y: '2008' },
  { t: '39º Congresso Brasileiro de Ortopedia e Traumatologia', loc: 'Brasil', y: '2007' },
  { t: 'XIII Congresso Brasileiro de Medicina e Cirurgia do Tornozelo e Pé', loc: 'Brasil', y: '2007' },
  { t: 'AAOS Annual Meeting', loc: 'Estados Unidos', y: '2006' },
  { t: 'AOFAS 2006 Specialty Day Program', loc: 'Chicago, IL · EUA', y: '2006' },
  { t: 'Congresso Nacional do Pé e Tornozelo · II Congresso Luso-Brasileiro', loc: 'Brasil', y: '2006' },
  { t: 'XII Congresso Brasileiro de Medicina e Cirurgia do Pé', loc: 'Brasil', y: '2005' }];

  const cursos = [
  { t: 'Artroscopia de Pé e Tornozelo · AANA', loc: 'Chicago · EUA' },
  { t: 'Advanced Techniques for Posterior Tibial Tendon', loc: 'Internacional' },
  { t: 'Arthrex · Minimally Invasive Surgical Treatment for Foot & Ankle', loc: 'Estados Unidos' },
  { t: 'Cirurgia minimamente invasiva e percutânea do Pé e Tornozelo', loc: 'Barcelona · Mendoza' },
  { t: 'Fellowship Orthopedic Foot & Ankle Center', loc: 'Columbus, Ohio · EUA · Dr. Thomas Lee' }];


  return (
    <section id="producao" style={{ padding: '120px 56px', background: PAPER }}>
      {/* Intro */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 80, marginBottom: 80, alignItems: 'flex-end' }} className="two-col">
        <Reveal><Label color={P.brand}>Produção & participação</Label></Reveal>
        <Reveal delay={100}>
          <h2 style={{
            fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
            fontSize: 'clamp(40px, 4.8vw, 68px)', lineHeight: 1.02, letterSpacing: '-0.02em', margin: 0
          }}>
            Três décadas <em style={{ color: P.brand }}>escrevendo, ensinando e estudando</em> o&nbsp;pé.
          </h2>
          <p style={{ fontSize: 15, lineHeight: 1.75, color: INK_SOFT, marginTop: 28, maxWidth: 620 }}>
            Artigos científicos em revistas peer-reviewed, publicações na imprensa especializada e
            leiga, participação em congressos brasileiros e internacionais, cursos e treinamentos em
            centros de referência nos Estados Unidos, Espanha e Argentina. Um recorte do currículo Lattes.
          </p>
        </Reveal>
      </div>

      {/* Artigos científicos — peer-reviewed */}
      <div style={{ borderTop: `1px solid ${RULE}`, paddingTop: 56, marginBottom: 96 }}>
        <Reveal>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap', gap: 16, marginBottom: 32 }}>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 36, color: INK }}>
              Artigos científicos
            </div>
            <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', color: INK_SOFT, fontWeight: 600 }}>
              {artigos.length} publicações · peer-reviewed
            </div>
          </div>
        </Reveal>
        <div>
          {artigos.map((a, i) =>
          <Reveal key={a.t + i} delay={i * 60}>
              <a
              href={a.u}
              target="_blank"
              rel="noopener noreferrer"
              className="pub-row"
              style={{
                display: 'grid', gridTemplateColumns: '90px 1fr 32px', gap: 32,
                padding: '32px 0', borderTop: `1px solid ${RULE}`, alignItems: 'flex-start',
                color: 'inherit', textDecoration: 'none',
                transition: 'background 200ms, padding 200ms'
              }}>
              
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 32, color: P.brand, lineHeight: 1 }}>
                  {a.y}
                </div>
                <div>
                  <div style={{
                  fontSize: 9, letterSpacing: '0.28em', textTransform: 'uppercase',
                  color: P.brand, fontWeight: 600, marginBottom: 10
                }}>
                    {a.role}
                  </div>
                  <div style={{
                  fontFamily: '"Cormorant Garamond", serif', fontSize: 26, color: INK,
                  fontWeight: 500, lineHeight: 1.22, letterSpacing: '-0.005em',
                  maxWidth: 760
                }}>
                    {a.t}
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 14px', marginTop: 14, fontSize: 12, color: INK_SOFT, letterSpacing: '0.02em' }}>
                    <span style={{ fontWeight: 600, color: INK }}>{a.j}</span>
                    <span style={{ opacity: 0.5 }}>—</span>
                    <span>{a.ref}</span>
                  </div>
                  {a.coa && <div style={{ fontSize: 12, color: INK_SOFT, marginTop: 8, lineHeight: 1.6, fontStyle: 'italic' }}>
                    com {a.coa}
                  </div>}
                </div>
                <div style={{ fontSize: 18, color: P.brand, textAlign: 'right' }}>↗</div>
              </a>
            </Reveal>
          )}
          <div style={{ borderTop: `1px solid ${RULE}` }} />
        </div>
        <Reveal delay={120}>
          <div style={{ marginTop: 28, fontSize: 12, color: INK_SOFT, letterSpacing: '0.04em' }}>
            Índice completo na <a href="https://rbo.org.br/artigos-autor/%20Cibele%20R%C3%A9ssio" target="_blank" rel="noopener noreferrer" style={{ color: P.brand, textDecoration: 'underline', textUnderlineOffset: 3 }}>Revista Brasileira de Ortopedia</a>.
          </div>
        </Reveal>
      </div>

      {/* Publicações na imprensa */}
      <div style={{ borderTop: `1px solid ${RULE}`, paddingTop: 56, marginBottom: 96 }}>
        <Reveal>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap', gap: 16, marginBottom: 32 }}>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 36, color: INK }}>
              Publicações na imprensa
            </div>
            <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', color: INK_SOFT, fontWeight: 600 }}>
              {publicacoes.length} artigos assinados
            </div>
          </div>
        </Reveal>
        <div>
          {publicacoes.map((p, i) =>
          <Reveal key={p.t + i} delay={i * 24}>
              <a
              href={linkFor(p)}
              target="_blank"
              rel="noopener noreferrer"
              className="pub-row"
              style={{
                display: 'grid', gridTemplateColumns: '80px 1fr 1.2fr 28px', gap: 24,
                padding: '22px 0', borderTop: `1px solid ${RULE}`, alignItems: 'baseline',
                color: 'inherit', textDecoration: 'none',
                transition: 'background 200ms, padding 200ms'
              }}>
              
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 22, color: P.brand }}>
                  {p.y}
                </div>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontSize: 22, color: INK, fontWeight: 500, lineHeight: 1.25 }}>
                  {p.t}
                </div>
                <div style={{ fontSize: 13, color: INK_SOFT, letterSpacing: '0.02em' }}>
                  {p.v}
                </div>
                <div style={{ fontSize: 16, color: P.brand, textAlign: 'right', alignSelf: 'center' }}>↗</div>
              </a>
            </Reveal>
          )}
          <div style={{ borderTop: `1px solid ${RULE}` }} />
        </div>
      </div>

      {/* Congressos e cursos — two columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56 }} className="two-col">
        {/* Congressos */}
        <Reveal>
          <div style={{ background: PAPER_WARM, padding: '40px 36px', height: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap', gap: 12, marginBottom: 24 }}>
              <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 32, color: INK }}>
                Congressos
              </div>
              <div style={{ fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', color: P.brand, fontWeight: 600 }}>
                Brasil & internacional
              </div>
            </div>
            {congressos.map((c, i) =>
            <div key={c.t + i} style={{
              padding: '18px 0', borderTop: `1px solid ${RULE}`,
              display: 'grid', gridTemplateColumns: '52px 1fr', gap: 16, alignItems: 'baseline'
            }}>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 18, color: P.brand }}>
                  {c.y}
                </div>
                <div>
                  <div style={{ fontSize: 14, color: INK, lineHeight: 1.45, fontWeight: 500 }}>{c.t}</div>
                  <div style={{ fontSize: 11, color: INK_SOFT, marginTop: 4, letterSpacing: '0.04em' }}>{c.loc}</div>
                </div>
              </div>
            )}
          </div>
        </Reveal>

        {/* Cursos & fellowships */}
        <Reveal delay={120}>
          <div style={{ background: P.brand, color: '#fff', padding: '40px 36px', height: '100%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap', gap: 12, marginBottom: 24 }}>
              <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 32 }}>
                Cursos & fellowships
              </div>
              <div style={{ fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', color: P.pale, fontWeight: 600 }}>
                Treinamento
              </div>
            </div>
            {cursos.map((c, i) =>
            <div key={c.t + i} style={{
              padding: '22px 0', borderTop: '1px solid rgba(255,255,255,0.22)'
            }}>
                <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 22, lineHeight: 1.2 }}>
                  {c.t}
                </div>
                <div style={{ fontSize: 11, color: P.pale, marginTop: 8, letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 600 }}>
                  {c.loc}
                </div>
              </div>
            )}
            <div style={{ marginTop: 32, fontSize: 13, lineHeight: 1.7, opacity: 0.88 }}>
              Membro Internacional da AOFAS · American Orthopaedic Foot & Ankle Society.
              Membro Titular da SBOT · Sociedade Brasileira de Ortopedia e Traumatologia.
            </div>
          </div>
        </Reveal>
      </div>
    </section>);

};

const Jornada = ({ P }) =>
<section id="jornada" style={{ padding: '110px 56px', background: P.brand, color: '#fff' }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 64, gap: 40, flexWrap: 'wrap' }}>
      <Reveal><Label color={P.pale} dot>Jornada do paciente</Label></Reveal>
      <Reveal delay={100}>
        <h2 style={{
        fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
        fontSize: 'clamp(40px, 5vw, 72px)', letterSpacing: '-0.02em', lineHeight: 0.98, margin: 0, color: '#fff',
        textAlign: 'right', maxWidth: 720
      }}>
          Da primeira <em>mensagem</em><br />
          ao último <em>retorno.</em>
        </h2>
      </Reveal>
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24 }} className="grid-4">
      {[
    ['01', 'Agendamento', 'WhatsApp, telefone ou formulário. Resposta em até 1 dia útil.'],
    ['02', 'Avaliação', 'Consulta de 60min com exame físico e mapeamento da pisada.'],
    ['03', 'Plano terapêutico', 'Indicação personalizada — palmilha, órtese, fisio ou cirurgia.'],
    ['04', 'Acompanhamento', 'Retornos programados. Garantia de adaptação para palmilhas.']].
    map(([n, t, d], i) =>
    <Reveal key={n} delay={i * 80}>
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.3)', paddingTop: 24 }}>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 56, lineHeight: 1, color: P.pale }}>{n}</div>
            <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 28, marginTop: 18, fontWeight: 500 }}>{t}</div>
            <div style={{ fontSize: 13, marginTop: 14, lineHeight: 1.7, opacity: 0.88 }}>{d}</div>
          </div>
        </Reveal>
    )}
    </div>
  </section>;


const Condicoes = ({ P }) =>
<section id="condicoes" style={{ padding: '120px 56px', background: PAPER_WARM }}>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 80, alignItems: 'flex-start' }} className="two-col">
      <div style={{ position: 'sticky', top: 100, alignSelf: 'flex-start' }}>
        <Reveal><Label color={P.brand}>Condições que tratamos</Label></Reveal>
        <Reveal delay={100}>
          <h2 style={{
          fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
          fontSize: 'clamp(36px, 4vw, 56px)', lineHeight: 1.02, margin: '20px 0 0', letterSpacing: '-0.015em'
        }}>
            Algumas das <em style={{ color: P.brand }}>queixas</em> que escutamos toda&nbsp;semana.
          </h2>
        </Reveal>
        <Reveal delay={200}>
          <p style={{ fontSize: 15, color: INK_SOFT, marginTop: 24, lineHeight: 1.7 }}>
            Se a sua não está aqui — provavelmente também tratamos. Pergunte pelo WhatsApp.
          </p>
        </Reveal>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0 }} className="grid-2">
        {[
      ['Fascite plantar', 'Dor no calcanhar ao acordar'],
      ['Esporão de calcâneo', 'Pontada plantar persistente'],
      ['Joanete (Hálux Valgo)', 'Deformidade na base do dedão'],
      ['Pé chato (plano)', 'Adulto e infantil'],
      ['Pé cavo', 'Arco excessivamente elevado'],
      ['Neuroma de Morton', 'Queimação entre os dedos'],
      ['Tendinite de Aquiles', 'Dor posterior do tornozelo'],
      ['Pé diabético', 'Cuidado preventivo e curativo'],
      ['Entorse de tornozelo', 'Agudo e recidivante'],
      ['Pé do corredor', 'Lesão por uso excessivo'],
      ['Unha encravada', 'Tratamento clínico e cirúrgico'],
      ['Metatarsalgia', 'Dor na planta anterior']].
      map(([t, d], i) =>
      <Reveal key={t} delay={i * 30}>
            <div style={{ padding: '22px 0', borderTop: `1px solid ${RULE}` }}>
              <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: 26, color: INK }}>{t}</div>
              <div style={{ fontSize: 12, color: INK_SOFT, marginTop: 6 }}>{d}</div>
            </div>
          </Reveal>
      )}
      </div>
    </div>
  </section>;


const Quote = ({ P }) =>
<section style={{ padding: '120px 56px', background: PAPER, textAlign: 'center' }}>
    <div style={{ maxWidth: 920, margin: '0 auto' }}>
      <Reveal delay={120}>
        <blockquote style={{
        fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic',
        fontSize: 'clamp(30px, 3.6vw, 52px)', lineHeight: 1.18, fontWeight: 400, color: INK,
        margin: '36px 0 0', letterSpacing: '-0.01em'
      }}>
          "O pé carrega o corpo inteiro. Tratá-lo bem é uma decisão que reverbera no joelho,
          no quadril, na coluna — <span style={{ color: P.brand }}>e na sua disposição para o dia.</span>"
        </blockquote>
      </Reveal>
      <Reveal delay={240}>
        <div style={{ marginTop: 40, fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase', color: INK_SOFT, fontWeight: 600 }}>
          Equipe Máxxima · Campo Belo
        </div>
      </Reveal>
    </div>
  </section>;


const Contato = ({ P }) =>
<section id="contato" style={{ padding: '120px 56px', background: INK, color: '#fff' }}>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80 }} className="two-col">
      <div>
        <Reveal><Label color={P.pale}>Agendamento</Label></Reveal>
        <Reveal delay={100}>
          <h2 style={{
          fontFamily: '"Cormorant Garamond", serif', fontWeight: 400,
          fontSize: 'clamp(48px, 5.8vw, 88px)', lineHeight: 0.95, letterSpacing: '-0.02em', margin: '20px 0 0'
        }}>
            Vamos cuidar<br />
            <em style={{ color: P.pink }}>do seu passo.</em>
          </h2>
        </Reveal>
        <Reveal delay={200}>
          <p style={{ fontSize: 16, lineHeight: 1.7, color: '#D4C9C3', maxWidth: 460, marginTop: 28 }}>
            Três caminhos para chegar até nós. Atendemos os principais convênios e também consultas particulares.
          </p>
          <div style={{ marginTop: 48, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
          {
            k: 'WhatsApp', v: '(11) 91711-1144', primary: true,
            href: 'https://wa.me/5511917111144?text=Olá! Gostaria de agendar uma consulta na Máxxima Ortopedia.'
          },
          {
            k: 'E-mail', v: 'cibeleortopedista@gmail.com',
            href: 'mailto:cibeleortopedista@gmail.com?subject=Consulta%20-%20M%C3%A1xxima%20Ortopedia&body=Ol%C3%A1%2C%20Dra.%20Cibele.%20Gostaria%20de%20agendar%20uma%20consulta.'
          },
          {
            k: 'Formulário', v: 'Receba retorno em 24h',
            href: 'https://wa.me/5511917111144?text=Olá! Gostaria de receber retorno sobre uma consulta na Máxxima Ortopedia.'
          }].
          map(({ k, v, primary, href }) =>
          <a key={k} href={href} target="_blank" rel="noopener noreferrer" style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            background: primary ? P.brand : 'transparent', color: '#fff', padding: '24px 28px', borderRadius: 8,
            border: primary ? 'none' : '1px solid rgba(255,255,255,0.2)', cursor: 'pointer',
            transition: 'transform 200ms', textDecoration: 'none'
          }}>
                <div>
                  <div style={{ fontSize: 10, letterSpacing: '0.28em', textTransform: 'uppercase', opacity: 0.7, fontWeight: 600 }}>{k}</div>
                  <div style={{ fontFamily: '"Cormorant Garamond", serif', fontStyle: 'italic', fontSize: k === 'E-mail' ? 24 : 32, marginTop: 6, wordBreak: 'break-word' }}>{v}</div>
                </div>
                <span style={{ fontSize: 22 }}>→</span>
              </a>
          )}
          </div>
        </Reveal>
      </div>
      <Reveal delay={150}>
        <iframe
        title="Localização da Máxxima Ortopedia"
        src="https://www.google.com/maps?q=Av.%20Vereador%20Jos%C3%A9%20Diniz%2C%203457%20-%20Sobreloja%2C%20Campo%20Belo%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004603-003&output=embed"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        style={{ width: '100%', height: 380, border: 0, display: 'block', filter: 'grayscale(0.15)' }}>
      </iframe>
        <div style={{ marginTop: 32, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }} className="grid-2">
          {[
        ['Endereço', 'Av. Vereador José Diniz, 3457 — Sobreloja\nCampo Belo · São Paulo · SP\nCEP 04603-003'],
        ['Horário', 'Seg a Sex · 8h às 19h'],
        ['Estacionamento', 'Valet disponível no edifício']].
        map(([k, v]) =>
        <div key={k} style={{ borderTop: '1px solid rgba(255,255,255,0.2)', paddingTop: 16 }}>
              <div style={{ fontSize: 10, letterSpacing: '0.24em', textTransform: 'uppercase', color: P.pink, fontWeight: 600 }}>{k}</div>
              <div style={{ fontSize: 12, color: '#D4C9C3', marginTop: 10, lineHeight: 1.75, whiteSpace: 'pre-line' }}>{v}</div>
            </div>
        )}
        </div>
      </Reveal>
    </div>
  </section>;


const Footer = ({ P }) =>
<footer style={{
  padding: '40px 56px', background: INK, color: '#D4C9C3',
  borderTop: '1px solid rgba(255,255,255,0.1)',
  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
  fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', flexWrap: 'wrap', gap: 20
}}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
      <img
      src="assets/maxxima-logo-trim.png"
      alt="Máxxima Ortopedia"
      style={{ height: 36, width: 'auto', display: 'block', filter: 'brightness(0) invert(1)' }} />
    
      <span>© 2026 Máxxima Ortopedia</span>
    </div>
    <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap', alignItems: 'center' }}>
      <a
      href="https://www.instagram.com/maxxima_ortopedia/"
      target="_blank"
      rel="noopener noreferrer"
      style={{ color: '#D4C9C3', textDecoration: 'none', letterSpacing: 'inherit' }}>
      Instagram</a>
      <span>Google</span>
      <span>Política de privacidade</span>
    </div>
  </footer>;


// ─── ROOT ──────────────────────────────────────────────────────────────────
const MaxximaSite = ({ tweaks }) => {
  const P = PALETTES[tweaks.palette] || PALETTES.classic;
  return (
    <div style={{ background: PAPER, color: INK, fontFamily: '"Manrope", sans-serif' }}>
      <Nav P={P} />
      <Hero P={P} density={tweaks.density} />
      <Ticker P={P} />
      <Clinica P={P} />
      <Tratamentos P={P} />
      <Doutora P={P} />
      <Producao P={P} />
      <Jornada P={P} />
      <Condicoes P={P} />
      <Quote P={P} />
      <Contato P={P} />
      <Footer P={P} />
    </div>);

};

window.MaxximaSite = MaxximaSite;
window.PALETTES = PALETTES;